angular
    .module('ngCribs')
    .factory('cribsFactory', function($http) {

        function getCribs() {
            return $http.get('../static/data/data.json');
        }

        return {
            getCribs: getCribs;
        }

    });
